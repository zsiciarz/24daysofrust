#include "fe.h"

void fe_pow22523(fe out,const fe z)
{
  fe t0;
  fe t1;
  fe t2;
  int i;

#include "pow22523.h"

  return;
}
